# 🩺 MedTrack-AI

**Python healthcare analytics educational prototype** featuring illustrative symptom matching, **synthetic** regional case trends, and map-based hospital search.

> ⚠️ **Not medical advice.** This repository is a demonstration, not a validated diagnostic model, clinical decision-support system, live outbreak service, or emergency service. Consult a healthcare professional for medical concerns.

## Features (working demo)
- **Symptom explorer:** transparent rules find overlapping symptoms among illustrative conditions; these are **not diagnoses or disease probabilities**.
- **Synthetic trends:** read fictional regional weekly cases from CSV; chart counts and display an example change indicator (**not actual outbreak risk**).
- **Hospital map search:** build a Google Maps query from manually entered coordinates. Maps provides search results; this app does **not** verify hospital listings, distances, capacity, or opening hours.

## Tech stack
Python, Streamlit, Pandas. No API key required. This demo does **not** train or run an AI/ML model yet.

## Get started
1. Install Python 3.10+.
2. Clone the repository and enter its directory.
3. Create a virtual environment: `python -m venv .venv`.
4. Activate it: Windows PowerShell: `.venv\Scripts\Activate.ps1`; macOS/Linux: `source .venv/bin/activate`.
5. Install: `python -m pip install -r requirements.txt`.
6. Run: `streamlit run app.py`.
7. Tests: `python -m pytest -q`.

## Project structure
```text
MedTrack-AI/
├── app.py
├── src/
│   ├── symptom_predictor.py
│   ├── disease_surveillance.py
│   ├── outbreak_risk.py
│   └── hospital_locator.py
├── data/sample_cases.csv
├── tests/test_core.py
├── docs/architecture.md
├── docs/project_report.md
├── screenshots/README.md
├── requirements.txt
├── .env.example
├── .gitignore
└── LICENSE
```

## Future development (not implemented)
- Train and externally validate a machine-learning symptom classifier on permissioned, appropriate data with medical expert review.
- Integrate authoritative disease surveillance data, with data-source attribution and reporting delays.
- Add authorized hospital search API with proper privacy and geolocation consent.
- Add accessibility, security testing, and appropriate healthcare safeguards.

## Data and privacy
The CSV is **fabricated** for teaching. Never upload patient records, private location histories, passwords, or API credentials to this repository.

## Author
**S Thanmaye** | Sapthagiri NPS University | GitHub: [thanmaye09](https://github.com/thanmaye09)

## License
MIT License — see [LICENSE](LICENSE).

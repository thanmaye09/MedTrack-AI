# Architecture (demo)

```text
Streamlit UI
  |-- Symptom explorer --> Transparent rule matching --> Illustrative overlaps
  |-- Trends -----------> Synthetic CSV --> Pandas --> Trend chart / change indicator
  `-- Hospital lookup --> Manual coordinates --> Google Maps search URL
```

There is no trained model, verified clinical dataset, live public-health feed, or hospital directory in this demo. See README for expansion ideas.

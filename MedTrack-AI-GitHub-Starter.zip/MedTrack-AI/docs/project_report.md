# MedTrack-AI — Short Project Report

## Problem
Information about symptoms, location-level case trends, and nearby hospitals is often spread across separate systems.

## Objective
Demonstrate a unified dashboard with symptom exploration, fictional regional case trend analysis, and convenient hospital map searches.

## Method
Python + Streamlit UI; transparent rule-based symptom overlap; Pandas analysis of synthetic weekly counts; Google Maps search link.

## Current limitations
Not a clinical tool; no trained or validated AI model; no live disease data; no risk predictions; hospital search results are external and unverified.

## Future work
Use licensed, verified disease data; obtain clinical supervision and privacy review; develop and rigorously validate an actual predictive model; integrate an authorized hospital search API; implement consent and data-security controls.

Place real screenshots of your running application here (do not upload private health/location data).

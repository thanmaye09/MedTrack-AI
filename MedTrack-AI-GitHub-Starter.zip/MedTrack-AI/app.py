"""MedTrack-AI: educational, synthetic-data dashboard."""
from pathlib import Path
import streamlit as st
from src.symptom_predictor import SYMPTOMS, match_symptoms
from src.disease_surveillance import load_cases, region_trend
from src.outbreak_risk import trend_indicator
from src.hospital_locator import hospital_search_url

st.set_page_config(page_title="MedTrack-AI Demo", page_icon="🩺", layout="wide")
st.title("🩺 MedTrack-AI")
st.warning("Educational prototype only. NOT an AI diagnostic tool, real disease surveillance, or an emergency service. Data is synthetic. Consult a qualified clinician for health advice.")

tab1, tab2, tab3 = st.tabs(["Symptom explorer", "Synthetic trends", "Hospital map search"])
with tab1:
    st.subheader("Illustrative symptom matching")
    st.caption("This feature uses predefined rules, not a trained or clinically validated AI model. Matches are not diagnoses or probabilities.")
    selected = st.multiselect("Select symptoms", SYMPTOMS)
    if st.button("Show example matches"):
        results = match_symptoms(selected)
        if not results:
            st.info("Select symptoms to see illustrative matches.")
        else:
            for result in results[:4]:
                st.write(f"**{result['label']}** — overlaps: {', '.join(result['matched_symptoms'])}")
    st.info("Seek urgent local medical care for severe symptoms such as difficulty breathing, chest pain, confusion, or loss of consciousness.")
with tab2:
    st.subheader("Fictional disease-count trends")
    df = load_cases(Path(__file__).parent / "data" / "sample_cases.csv")
    region = st.selectbox("Choose fictional region", sorted(df["region"].unique()))
    trend = region_trend(df, region)
    st.line_chart(trend.set_index("week")["cases"])
    st.metric("Example trend indicator", trend_indicator(trend["cases"]))
    st.caption("Synthetic case counts, not live surveillance data. Changes in counts alone do not determine outbreak risk.")
with tab3:
    st.subheader("Find hospitals on a map")
    st.caption("Enter a location manually. Coordinates are only used to build an external map-search link.")
    lat = st.number_input("Latitude", min_value=-90.0, max_value=90.0, value=12.9716, format="%.5f")
    lon = st.number_input("Longitude", min_value=-180.0, max_value=180.0, value=77.5946, format="%.5f")
    st.link_button("Search hospitals in Google Maps", hospital_search_url(lat, lon))
    st.caption("Example defaults are central Bengaluru. Results, distances, quality, and availability are provided by the external map service and are not verified here.")

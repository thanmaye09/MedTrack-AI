from src.symptom_predictor import match_symptoms
from src.outbreak_risk import trend_indicator
from src.hospital_locator import hospital_search_url
from src.disease_surveillance import load_cases, region_trend
from pathlib import Path

def test_symptom_matches():
    assert match_symptoms(["sneezing", "itchy eyes"])[0]["overlap_count"] == 2
    assert match_symptoms([]) == []

def test_trend():
    assert trend_indicator([10, 14]) == "Increasing (25% or more)"
    assert trend_indicator([0, 0]) == "No change"

def test_hospital_url():
    assert "google.com/maps/search" in hospital_search_url(12.97, 77.59)

def test_csv():
    df = load_cases(Path(__file__).resolve().parents[1] / "data" / "sample_cases.csv")
    assert len(region_trend(df, "North Zone")) == 4

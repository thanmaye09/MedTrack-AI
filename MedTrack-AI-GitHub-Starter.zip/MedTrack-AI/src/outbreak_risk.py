"""Example-only change indicator; NOT a public-health outbreak assessment."""

def trend_indicator(counts):
    values = list(counts)
    if len(values) < 2:
        return "Not enough data"
    previous, current = values[-2:]
    if previous == 0:
        return "Increase from zero" if current > 0 else "No change"
    change = (current - previous) / previous
    if change >= 0.25:
        return "Increasing (25% or more)"
    if change <= -0.25:
        return "Decreasing (25% or more)"
    return "Relatively stable"

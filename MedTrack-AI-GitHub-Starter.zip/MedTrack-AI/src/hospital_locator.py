"""Open a map search for hospitals; does not verify proximity or availability."""
from urllib.parse import urlencode

def hospital_search_url(latitude, longitude):
    lat, lon = float(latitude), float(longitude)
    if not -90 <= lat <= 90 or not -180 <= lon <= 180:
        raise ValueError("Invalid latitude or longitude")
    return "https://www.google.com/maps/search/?" + urlencode({
        "api": "1", "query": f"hospitals near {lat},{lon}"
    })

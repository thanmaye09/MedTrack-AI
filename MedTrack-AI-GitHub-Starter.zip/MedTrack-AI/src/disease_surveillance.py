"""Analysis of fictional, synthetic case counts."""
import pandas as pd

REQUIRED_COLUMNS = {"region", "week", "cases"}

def load_cases(path):
    df = pd.read_csv(path)
    if not REQUIRED_COLUMNS.issubset(df.columns):
        raise ValueError(f"Missing columns: {REQUIRED_COLUMNS - set(df.columns)}")
    df["cases"] = pd.to_numeric(df["cases"], errors="raise")
    if (df["cases"] < 0).any():
        raise ValueError("Case counts cannot be negative")
    return df

def region_trend(df, region):
    subset = df.loc[df["region"] == region, ["week", "cases"]].copy()
    return subset.sort_values("week")

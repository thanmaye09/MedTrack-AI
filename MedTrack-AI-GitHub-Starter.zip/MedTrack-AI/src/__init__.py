"""MedTrack AI educational demo package."""

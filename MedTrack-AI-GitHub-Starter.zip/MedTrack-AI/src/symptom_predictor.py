"""Transparent rule-based symptom matching, NOT a medical diagnosis."""

CONDITIONS = {
    "Common cold (illustrative)": {"cough", "runny nose", "sore throat", "sneezing"},
    "Flu-like illness (illustrative)": {"fever", "cough", "fatigue", "body aches", "headache"},
    "Allergy-like symptoms (illustrative)": {"sneezing", "runny nose", "itchy eyes"},
    "Stomach illness (illustrative)": {"nausea", "vomiting", "diarrhea", "stomach pain"},
}
SYMPTOMS = sorted(set().union(*CONDITIONS.values()))

def match_symptoms(symptoms):
    """Return illustrative matches ranked by overlap; no disease probabilities."""
    observed = set(symptoms)
    if not observed:
        return []
    matches = []
    for name, typical in CONDITIONS.items():
        overlapping = sorted(observed & typical)
        if overlapping:
            matches.append({"label": name, "matched_symptoms": overlapping,
                            "overlap_count": len(overlapping)})
    return sorted(matches, key=lambda item: (-item["overlap_count"], item["label"]))
